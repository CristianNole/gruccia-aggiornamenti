/* Gruccia — aggiornamenti OTA (senza reinstallare l'app), con il plugin capacitor-updater in modalità manuale.
   L'app legge un piccolo file "version.json" all'indirizzo qui sotto; se trova una versione più nuova scarica il
   pacchetto, ne controlla l'impronta e lo applica al prossimo avvio. Si aggiorna solo la parte web (schermate, logica,
   stili): per cambiare icona, plugin o parti native serve ancora un nuovo APK.
   Le due costanti qui sotto le scrive lo script "npm run ota": non modificarle a mano. */
(function(){
"use strict";
const VERSIONE = "1.0.5";
const UPDATE_URL = "https://cristiannole.github.io/gruccia-aggiornamenti";   /* es. "https://utente.github.io/gruccia-aggiornamenti" — vuoto = aggiornamenti OTA spenti */

const cap = window.Capacitor || null;
const nativo = !!(cap && cap.isNativePlatform && cap.isNativePlatform());
const plug = n => (cap && cap.Plugins && cap.Plugins[n]) || null;
const U = nativo ? plug("CapacitorUpdater") : null;

/* confronto tra versioni "1.2.3": >0 se a è più nuova di b */
function cmp(a,b){ const x=String(a).split(".").map(n=>parseInt(n,10)||0), y=String(b).split(".").map(n=>parseInt(n,10)||0);
  for(let i=0;i<3;i++){ if((x[i]||0)!==(y[i]||0)) return (x[i]||0)-(y[i]||0); } return 0; }

async function leggiJson(url){
  const http=plug("CapacitorHttp");
  if(nativo && http){ const r=await http.request({url, method:"GET", headers:{"Cache-Control":"no-cache"}, readTimeout:20000});
    if(r.status<200||r.status>=300) throw new Error("http "+r.status);
    return typeof r.data==="string" ? JSON.parse(r.data) : r.data; }
  const r=await fetch(url,{cache:"no-store"}); if(!r.ok) throw new Error("http "+r.status); return r.json();
}

let stato = { versione:VERSIONE, attivo:!!(U&&UPDATE_URL), ultima:null, pronta:null, errore:null };
let inCorso = null;

/* Risultato: "spento" | "aggiornata" | "pronta" (scaricata: si applica al prossimo avvio) | "errore" */
function controlla(){
  if(!U || !UPDATE_URL) return Promise.resolve("spento");
  if(inCorso) return inCorso;
  inCorso=(async()=>{
    try{
      const base=UPDATE_URL.replace(/\/+$/,"");
      const info=await leggiJson(base+"/version.json?t="+Date.now());
      if(!info || !/^\d+\.\d+\.\d+$/.test(String(info.version)) || !/^https:\/\//.test(String(info.url||""))) throw new Error("version.json non valido");
      stato.ultima=info.version;
      if(cmp(info.version, VERSIONE)<=0) return "aggiornata";
      if(stato.pronta===info.version) return "pronta";
      const o={ url:info.url, version:info.version }; if(info.checksum) o.checksum=String(info.checksum);
      const b=await U.download(o);
      await U.next({ id:b.id });          /* si attiva alla prossima apertura dell'app, senza interrompere l'uso */
      stato.pronta=info.version; stato.errore=null;
      return "pronta";
    }catch(e){ stato.errore=String((e&&e.message)||e); return "errore"; }
    finally{ inCorso=null; }
  })();
  return inCorso;
}

window.GrucciaUpdate = { versione:VERSIONE, attivo:()=>!!(U&&UPDATE_URL), stato:()=>Object.assign({},stato), controlla };

if(U){
  /* dico al plugin che questa versione si è avviata bene: se non lo sente entro pochi secondi torna da solo alla precedente */
  const pronto=()=>{ try{ U.notifyAppReady().catch(()=>{}); }catch(_){} };
  if(document.readyState==="complete") setTimeout(pronto,800); else window.addEventListener("load",()=>setTimeout(pronto,800));
  if(UPDATE_URL) setTimeout(()=>{ controlla(); }, 6000);
}
})();
