/* Gruccia — aggiornamenti OTA (senza reinstallare l'app), con il plugin capacitor-updater in modalità manuale.
   L'app legge un piccolo file "version.json" all'indirizzo qui sotto; se trova una versione più nuova scarica il
   pacchetto, ne controlla l'impronta e lo applica al prossimo avvio. Si aggiorna solo la parte web (schermate, logica,
   stili): per cambiare icona, plugin o parti native serve ancora un nuovo APK.
   Le due costanti qui sotto le scrive lo script "npm run ota": non modificarle a mano. */
(function(){
"use strict";
const VERSIONE = "1.0.9";
const UPDATE_URL = "https://cristiannole.github.io/gruccia-aggiornamenti";   /* es. "https://utente.github.io/gruccia-aggiornamenti" — vuoto = aggiornamenti OTA spenti */

const cap = window.Capacitor || null;
const nativo = !!(cap && cap.isNativePlatform && cap.isNativePlatform());
const plug = n => (cap && cap.Plugins && cap.Plugins[n]) || null;
const U = nativo ? plug("CapacitorUpdater") : null;

/* confronto tra versioni "1.2.3": >0 se a è più nuova di b */
function cmp(a,b){ const x=String(a).split(".").map(n=>parseInt(n,10)||0), y=String(b).split(".").map(n=>parseInt(n,10)||0);
  for(let i=0;i<3;i++){ if((x[i]||0)!==(y[i]||0)) return (x[i]||0)-(y[i]||0); } return 0; }

async function leggiJson(url){
  const http=plug("CapacitorHttp");
  if(nativo && http){ const r=await http.request({url, method:"GET", headers:{"Cache-Control":"no-cache"}, readTimeout:20000});
    if(r.status<200||r.status>=300) throw new Error("http "+r.status);
    return typeof r.data==="string" ? JSON.parse(r.data) : r.data; }
  const r=await fetch(url,{cache:"no-store"}); if(!r.ok) throw new Error("http "+r.status); return r.json();
}

let stato = { versione:VERSIONE, attivo:!!(U&&UPDATE_URL), ultima:null, pronta:null, errore:null };
let inCorso = null;

/* Risultato: "spento" | "aggiornata" | "pronta" (scaricata: si applica al prossimo avvio) | "errore" */
function controlla(){
  if(!U || !UPDATE_URL) return Promise.resolve("spento");
  if(inCorso) return inCorso;
  inCorso=(async()=>{
    try{
      const base=UPDATE_URL.replace(/\/+$/,"");
      const info=await leggiJson(base+"/version.json?t="+Date.now());
      if(!info || !/^\d+\.\d+\.\d+$/.test(String(info.version)) || !/^https:\/\//.test(String(info.url||""))) throw new Error("version.json non valido");
      stato.ultima=info.version;
      if(cmp(info.version, VERSIONE)<=0) return "aggiornata";
      if(stato.pronta===info.version) return "pronta";
      const o={ url:info.url, version:info.version }; if(info.checksum) o.checksum=String(info.checksum);
      const b=await U.download(o);
      await U.next({ id:b.id });          /* si attiva comunque alla prossima apertura dell'app */
      stato.pronta=info.version; stato.id=b.id; stato.errore=null;
      avvisa(info.version);               /* e intanto un avviso permette di passare subito alla versione nuova */
      return "pronta";
    }catch(e){ stato.errore=String((e&&e.message)||e); return "errore"; }
    finally{ inCorso=null; }
  })();
  return inCorso;
}

/* passa subito alla versione scaricata: l'app si ricarica */
function applica(){ if(!U || !stato.id) return Promise.resolve(false); return U.set({ id:stato.id }).then(()=>true, e=>{ stato.errore=String((e&&e.message)||e); return false; }); }
/* avviso in alto: "Aggiornamento pronto · Aggiorna ora". Si può chiudere: in quel caso l'aggiornamento entra alla prossima apertura */
function avvisa(versione){
  try{
    if(document.getElementById("gr-upd")) return;
    const d=document.createElement("div"); d.id="gr-upd";
    d.style.cssText="position:fixed;left:50%;transform:translateX(-50%);top:calc(10px + env(safe-area-inset-top,0px));z-index:2000;display:flex;align-items:center;gap:10px;max-width:92%;padding:9px 10px 9px 16px;border-radius:999px;background:#1B1730;border:1px solid #6F58C9;color:#F2EEFF;font:600 14px/1.2 Manrope,system-ui,sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.45)";
    const t=document.createElement("span"); t.textContent="Versione "+versione+" pronta";
    const ok=document.createElement("button"); ok.textContent="Aggiorna ora";
    ok.style.cssText="border:0;border-radius:999px;padding:8px 14px;font:700 13px/1 Manrope,system-ui,sans-serif;color:#14101F;background:linear-gradient(90deg,#8FA2FF,#C58BFF 55%,#FF9FE4)";
    const no=document.createElement("button"); no.textContent="✕"; no.setAttribute("aria-label","Più tardi");
    no.style.cssText="border:0;background:none;color:#B9B2D6;font:700 15px/1 system-ui,sans-serif;padding:6px 8px";
    ok.addEventListener("click",()=>{ ok.disabled=true; ok.textContent="Aggiorno…"; applica().then(fatto=>{ if(!fatto){ t.textContent="Chiudi e riapri l’app per aggiornare"; ok.remove(); } }); });
    no.addEventListener("click",()=>d.remove());
    d.appendChild(t); d.appendChild(ok); d.appendChild(no); document.body.appendChild(d);
  }catch(_){}
}

window.GrucciaUpdate = { versione:VERSIONE, attivo:()=>!!(U&&UPDATE_URL), stato:()=>Object.assign({},stato), controlla, applica };

if(U){
  /* dico al plugin che questa versione si è avviata bene: se non lo sente entro pochi secondi torna da solo alla precedente */
  const pronto=()=>{ try{ U.notifyAppReady().catch(()=>{}); }catch(_){} };
  if(document.readyState==="complete") setTimeout(pronto,800); else window.addEventListener("load",()=>setTimeout(pronto,800));
  if(UPDATE_URL){
    /* cerca gli aggiornamenti da sola: appena l'app si apre e ogni volta che ci si torna, al più una volta ogni 10 minuti */
    let ultimo=0;
    const cerca=()=>{ const ora=Date.now(); if(ora-ultimo<600000) return; ultimo=ora; controlla(); };
    setTimeout(cerca, 1500);
    document.addEventListener("visibilitychange",()=>{ if(document.visibilityState==="visible") cerca(); });
  }
}
})();
