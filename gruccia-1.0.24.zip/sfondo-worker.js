/* Gruccia — toglie lo sfondo da una foto, in un thread a parte: l'app resta fluida mentre il modello lavora.
   Modello: RMBG-1.4 (BRIA AI), eseguito con transformers.js + ONNX Runtime in WebAssembly, un solo thread.
   Il file del modello (44 MB) non è dentro l'app: sfondo.js lo scarica una volta e lo mette nella cache del dispositivo;
   qui la richiesta di quel file viene servita dalla cache, tutto il resto (motore, configurazione) è dentro l'app.
   Messaggi: { id, data: Float32Array 1x3xLxL già normalizzata, side: L }  ->  { id, mask: Uint8Array LxL } oppure { id, error } */
const U = p => new URL(p, self.location.href).href;
const CACHE = "gruccia-modelli";
const KEY = "https://huggingface.co/briaai/RMBG-1.4/resolve/main/onnx/model_quantized.onnx";
const MODEL = "briaai/RMBG-1.4";

/* il motore chiede il modello come un file locale: glielo do dalla cache, dove sfondo.js lo ha salvato */
const realFetch = self.fetch.bind(self);
self.fetch = async (input, init) => {
  const url = String((input && input.url) || input);
  if (/RMBG-1\.4\/onnx\/model_quantized\.onnx/.test(url)) {
    const c = await caches.open(CACHE), r = await c.match(KEY);
    if (r) return r;
    return new Response("", { status: 404 });
  }
  return realFetch(input, init);
};

let T = null, model = null, loading = null;
function load() {
  if (loading) return loading;
  loading = (async () => {
    T = await import(U("vendor/transformers.min.js"));
    T.env.allowRemoteModels = false; T.env.allowLocalModels = true; T.env.localModelPath = U("models/");
    T.env.useBrowserCache = false; T.env.useWasmCache = false;
    const w = T.env.backends.onnx.wasm;
    w.numThreads = 1; w.proxy = false;
    const r = await realFetch(U("vendor/ort-wasm-simd-threaded.wasm")); if (!r.ok) throw new Error("wasm " + r.status);
    w.wasmBinary = await r.arrayBuffer();
    w.wasmPaths = { mjs: U("vendor/ort-wasm-simd-threaded.js"), wasm: U("vendor/ort-wasm-simd-threaded.wasm") };
    model = await T.AutoModel.from_pretrained(MODEL, { device: "wasm", dtype: "q8", config: { model_type: "custom" } });
    return true;
  })();
  loading.catch(() => { loading = null; });
  return loading;
}

self.onmessage = async e => {
  const { id, data, side } = e.data || {};
  try {
    await load();
    if (!data) { self.postMessage({ id, ok: true }); return; }   /* solo riscaldamento */
    const input = new T.Tensor("float32", data, [1, 3, side, side]);
    const out = await model({ input });
    const o = out.output || out[Object.keys(out)[0]], d = o.data, N = side * side;
    /* come nel codice di riferimento del modello: il risultato va riportato tra il suo minimo e il suo massimo */
    let lo = Infinity, hi = -Infinity;
    for (let i = 0; i < N; i++) { const v = d[i]; if (v < lo) lo = v; if (v > hi) hi = v; }
    const k = hi > lo ? 255 / (hi - lo) : 0, mask = new Uint8Array(N);
    for (let i = 0; i < N; i++) mask[i] = (d[i] - lo) * k;
    try { for (const n in out) { const t = out[n]; if (t && typeof t.dispose === "function") t.dispose(); } if (typeof input.dispose === "function") input.dispose(); } catch (_) {}
    self.postMessage({ id, mask }, [mask.buffer]);
  } catch (err) {
    self.postMessage({ id, error: String((err && (err.message || err.code)) || err) });
  }
};
