/* ---------- Gruccia — scontorno vero dei capi: toglie lo sfondo da qualsiasi foto, sul telefono ----------
   Script classico, senza dipendenze da index.html. Espone:
     window.GrucciaSfondo = {
       presente(): Promise<boolean>          il modello è già sul dispositivo?
       scarica(onProg): Promise<boolean>     lo scarica (44 MB, una volta sola); onProg(frazione 0..1)
       ritaglia(src): Promise<null | { cut: dataURL con trasparenza, tagliata attorno al capo, f: quota di foto occupata dal capo }>
     }
   Il lavoro pesante avviene in sfondo-worker.js. Non lancia mai: se qualcosa va storto restituisce null/false. */
(function(){
"use strict";
const BASE=(document.currentScript&&document.currentScript.src)||location.href;
const U=p=>new URL(p,BASE).href;
const CACHE="gruccia-modelli";
const KEY="https://huggingface.co/briaai/RMBG-1.4/resolve/main/onnx/model_quantized.onnx";
const BYTES=44403226;       /* dimensione attesa del modello: se non coincide il file è incompleto */
const SIDE=1024;            /* il modello lavora a 1024 x 1024 */
const OUT=640;              /* lato lungo dello scontorno salvato */
const T_FIRST=120000, T_RUN=90000;

let worker=null, seq=0, fails=0, down=null; const wait=new Map();
let queue=Promise.resolve();

async function presente(){
  try{ if(!("caches" in self)) return false; const c=await caches.open(CACHE), r=await c.match(KEY); if(!r) return false;
    const n=+(r.headers.get("x-gruccia-bytes")||0); return n===BYTES; }catch(_){ return false; }
}
function scarica(onProg){
  if(down) return down;
  down=(async()=>{
    try{
      if(await presente()) return true;
      if(!("caches" in self)) return false;
      const r=await fetch(KEY,{mode:"cors",credentials:"omit"}); if(!r.ok||!r.body) return false;
      const rd=r.body.getReader(), parts=[]; let n=0;
      for(;;){ const {done,value}=await rd.read(); if(done) break; parts.push(value); n+=value.length; if(onProg){ try{ onProg(Math.min(1,n/BYTES)); }catch(_){} } }
      if(n!==BYTES) return false;
      const c=await caches.open(CACHE);
      await c.put(KEY,new Response(new Blob(parts,{type:"application/octet-stream"}),{headers:{"content-type":"application/octet-stream","x-gruccia-bytes":String(n)}}));
      return true;
    }catch(e){ try{ console.warn("[sfondo] scaricamento:",e&&(e.message||e)); }catch(_){} return false; }
    finally{ down=null; }
  })();
  return down;
}

function start(){
  if(worker) return worker;
  worker=new Worker(U("sfondo-worker.js"),{type:"module"});
  worker.onmessage=e=>{ const m=e.data||{}, w=wait.get(m.id); if(!w) return; wait.delete(m.id); clearTimeout(w.t); if(m.error) w.rej(new Error(m.error)); else w.res(m); };
  worker.onerror=e=>{ const err=new Error((e&&e.message)||"worker"); for(const w of wait.values()){ clearTimeout(w.t); w.rej(err); } wait.clear(); try{ worker.terminate(); }catch(_){} worker=null; };
  return worker;
}
function ask(msg,transfer,ms){
  return new Promise((res,rej)=>{ const id=++seq, w=start();
    const t=setTimeout(()=>{ wait.delete(id); try{ w.terminate(); }catch(_){} if(worker===w) worker=null; rej(new Error("tempo scaduto")); },ms);
    wait.set(id,{res,rej,t}); w.postMessage(Object.assign({id},msg),transfer||[]); });
}

let warm=false;
async function run(src){
  if(fails>=3||!(await presente())) return null;
  const sw=src.width||src.naturalWidth, sh=src.height||src.naturalHeight; if(!sw||!sh) return null;
  /* 1. la foto a 1024 x 1024 (deformata: così vuole il modello), normalizzata */
  const c=document.createElement("canvas"); c.width=SIDE; c.height=SIDE; const g=c.getContext("2d",{willReadFrequently:true});
  g.imageSmoothingQuality="high"; g.drawImage(src,0,0,SIDE,SIDE);
  const px=g.getImageData(0,0,SIDE,SIDE).data, N=SIDE*SIDE, data=new Float32Array(N*3);
  for(let i=0;i<N;i++){ const o=i*4; data[i]=px[o]/255-.5; data[N+i]=px[o+1]/255-.5; data[2*N+i]=px[o+2]/255-.5; }
  c.width=c.height=1;
  /* 2. la maschera, dal thread a parte */
  const m=await ask({data,side:SIDE},[data.buffer],warm?T_RUN:T_FIRST); warm=true;
  const mask=m.mask; if(!mask||mask.length!==N) return null;
  /* 3. maschera -> trasparenza della foto, alla misura di uscita */
  const k=Math.min(1,OUT/Math.max(sw,sh)), W=Math.max(1,Math.round(sw*k)), H=Math.max(1,Math.round(sh*k));
  const mc=document.createElement("canvas"); mc.width=SIDE; mc.height=SIDE; const mg=mc.getContext("2d");
  const mi=mg.createImageData(SIDE,SIDE), md=mi.data; for(let i=0;i<N;i++){ md[i*4+3]=mask[i]; } mg.putImageData(mi,0,0);
  const ms=document.createElement("canvas"); ms.width=W; ms.height=H; const sg=ms.getContext("2d",{willReadFrequently:true}); sg.imageSmoothingQuality="high"; sg.drawImage(mc,0,0,W,H);
  const a=sg.getImageData(0,0,W,H).data;
  const o=document.createElement("canvas"); o.width=W; o.height=H; const og=o.getContext("2d",{willReadFrequently:true}); og.imageSmoothingQuality="high"; og.drawImage(src,0,0,W,H);
  const im=og.getImageData(0,0,W,H), d=im.data; let x0=W,y0=H,x1=-1,y1=-1,cnt=0;
  for(let i=0;i<W*H;i++){ let v=a[i*4+3]; v=v<20?0:v>235?255:v; d[i*4+3]=v;
    if(v>40){ cnt++; const x=i%W, y=(i-x)/W; if(x<x0)x0=x; if(x>x1)x1=x; if(y<y0)y0=y; if(y>y1)y1=y; } }
  const f=cnt/(W*H);
  /* niente capo riconoscibile, oppure «capo» grande quanto tutta la foto: meglio la foto intera che un ritaglio sbagliato */
  if(f<.03||f>.97||x1<=x0||y1<=y0) return {cut:null, f};
  og.putImageData(im,0,0);
  const ow=x1-x0+1, oh=y1-y0+1, enc=s=>{ const t=document.createElement("canvas"); t.width=Math.max(1,Math.round(ow*s)); t.height=Math.max(1,Math.round(oh*s)); const tg=t.getContext("2d"); tg.imageSmoothingQuality="high"; tg.drawImage(o,x0,y0,ow,oh,0,0,t.width,t.height);
    let u=t.toDataURL("image/webp",.88); if(u.indexOf("data:image/webp")!==0) u=t.toDataURL("image/png"); return u; };
  let u=enc(1); if(u.length>400000) u=enc(.7); if(u.length>400000) u=enc(.5);
  return {cut:u, f};
}
/* una foto alla volta: due insieme raddoppierebbero solo la memoria */
function ritaglia(src){
  const p=queue.then(()=>run(src)).then(r=>{ if(r) fails=0; return r; },e=>{ fails++; try{ console.warn("[sfondo]",e&&(e.message||e)); }catch(_){} return null; });
  queue=p.then(()=>{},()=>{});
  return p;
}
window.GrucciaSfondo={presente,scarica,ritaglia,BYTES};
})();
