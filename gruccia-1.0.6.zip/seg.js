/* ---------- scontorno dei capi indossati: riconosce sul telefono, pixel per pixel, cosa è maglia, pantalone, scarpa... ----------
   Script classico, senza dipendenze da index.html. Espone:
     window.GrucciaSeg = { ready(): Promise<boolean>, mask(src, box, hint, signal): Promise<null | { mask: canvas, score: 0..1 }> }
   Modello: SegFormer-B0 addestrato sui vestiti (18 classi ATR), eseguito con transformers.js + ONNX Runtime in WebAssembly, un solo thread.
   Tutto è dentro l'app (cartelle vendor/ e models/): niente rete. La foto viene analizzata UNA volta e il risultato resta in memoria
   finché vive il canvas di origine, così più chiamate a mask() sulla stessa foto costano una sola inferenza.
   Non lancia mai: se qualcosa va storto restituisce null e chi chiama usa il ritaglio a riquadro di sempre. */
(function(){
"use strict";
const BASE=(document.currentScript&&document.currentScript.src)||location.href;
const U=p=>new URL(p,BASE).href;
const MODEL="Xenova/segformer_b0_clothes";
const SIDE=640;            /* lato lungo dato al modello: lui lavora comunque a 512x512 */
const T_LOAD=45000;        /* tempo massimo per caricare motore e modello (solo la prima volta) */
const T_RUN=20000;         /* tempo massimo per analizzare una foto */
const OUT_MAX=1024;        /* lato lungo massimo della maschera restituita */

/* classi del modello (ATR). Le etichette si confrontano senza maiuscole né trattini. */
const ID={background:0,hat:1,hair:2,sunglasses:3,upperclothes:4,skirt:5,pants:6,dress:7,belt:8,leftshoe:9,rightshoe:10,face:11,leftleg:12,rightleg:13,leftarm:14,rightarm:15,bag:16,scarf:17};
const HAT=1,GLASSES=3,UPPER=4,SKIRT=5,PANTS=6,DRESS=7,BELT=8,LSHOE=9,RSHOE=10,BAG=16,SCARF=17;
const BODY=new Set([2,11,12,13,14,15]);   /* capelli, viso, braccia, gambe: mai dentro un capo */
const UPPER_CATS=new Set(["sopra","maglieria","capospalla"]);
/* accessori che il modello conosce, per tipo */
const ACC={cappello:HAT,berretto:HAT,cappellino:HAT,occhiali:GLASSES,borsa:BAG,zaino:BAG,borsetta:BAG,sciarpa:SCARF,foulard:SCARF,cintura:BELT};

let lib=null, seg=null, loading=null, fails=0, off=false;
let queue=Promise.resolve();              /* una sola inferenza alla volta */
const views=new WeakMap();                /* canvas di origine -> Map(chiave della zona -> Promise<vista>) */

const pause=()=>new Promise(r=>setTimeout(r,0));
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
/* dopo due errori nella sessione si spegne da solo. Lo stesso errore visto da più chiamate in attesa conta una volta. */
function fail(e){ if(e&&typeof e==="object"){ if(e.seen) return; try{ e.seen=true; }catch(_){} } fails++; if(fails>=2) off=true; try{ console.warn("[seg]",e&&(e.message||e.code||e)); }catch(_){} }
/* aspetta p al massimo ms millisecondi e smette subito se il segnale annulla */
function limit(p,ms,signal){
  return new Promise((res,rej)=>{
    let done=false; const end=(f,v)=>{ if(done) return; done=true; clearTimeout(t); if(signal) signal.removeEventListener("abort",ab); f(v); };
    const t=setTimeout(()=>end(rej,{code:"timeout"}),ms), ab=()=>end(rej,{code:"cancelled"});
    if(signal){ if(signal.aborted) return ab(); signal.addEventListener("abort",ab); }
    p.then(v=>end(res,v),e=>end(rej,e));
  });
}

/* ---------- caricamento, solo al primo uso ---------- */
function load(){
  if(loading) return loading;
  loading=(async()=>{
    if(typeof WebAssembly!=="object") throw new Error("WebAssembly assente");
    const T=await import(U("vendor/transformers.min.js"));
    T.env.allowRemoteModels=false; T.env.allowLocalModels=true; T.env.localModelPath=U("models/");
    T.env.useBrowserCache=false; T.env.useWasmCache=false;      /* i file sono già nell'app */
    const w=T.env.backends.onnx.wasm;
    w.numThreads=1; w.proxy=false;                              /* niente SharedArrayBuffer nella WebView di Capacitor */
    /* il binario lo leggiamo noi come ArrayBuffer: così non dipende dal tipo MIME servito né dalla compilazione in streaming.
       Il file che lo avvia ha estensione .js (su iOS .mjs verrebbe servito come dato generico e rifiutato come modulo). */
    const r=await fetch(U("vendor/ort-wasm-simd-threaded.wasm")); if(!r.ok) throw new Error("wasm "+r.status);
    w.wasmBinary=await r.arrayBuffer();
    w.wasmPaths={mjs:U("vendor/ort-wasm-simd-threaded.js"),wasm:U("vendor/ort-wasm-simd-threaded.wasm")};
    /* modello e preparazione dell'immagine caricati direttamente: la funzione pipeline() di transformers.js verifica l'esistenza
       dei file con una richiesta che con i soli file locali non riesce, e resterebbe senza preparazione dell'immagine */
    const proc=await T.AutoImageProcessor.from_pretrained(MODEL);
    const model=await T.AutoModelForSemanticSegmentation.from_pretrained(MODEL,{device:"wasm",dtype:"q8"});
    /* numero di classe del modello -> numero usato qui, letto dai nomi nel config (di norma coincidono) */
    const names=(model.config&&model.config.id2label)||{}, map=new Uint8Array(256); let known=0;
    for(let i=0;i<256;i++) map[i]=i<18?i:0;
    for(const k in names){ const id=ID[String(names[k]).toLowerCase().replace(/[^a-z]/g,"")]; if(id!=null&&+k<256){ map[+k]=id; known++; } }
    if(Object.keys(names).length&&known<12) throw new Error("etichette del modello non riconosciute");
    seg={proc,model,map};
    lib=T; return true;
  })();
  loading.catch(()=>{});
  return loading;
}
async function ready(){
  if(off) return false;
  try{ await limit(load(),T_LOAD); return true; }
  catch(e){ off=true; try{ console.warn("[seg] non disponibile:",e&&(e.message||e.code||e)); }catch(_){} return false; }
}

/* ---------- analisi di una zona della foto: una "vista" ha la mappa delle classi e i colori, a bassa risoluzione ---------- */
async function parse(src,z){
  const sx=z[0]*src.width, sy=z[1]*src.height, sw=Math.max(1,(z[2]-z[0])*src.width), sh=Math.max(1,(z[3]-z[1])*src.height);
  const k=Math.min(1,SIDE/Math.max(sw,sh)), W=Math.max(8,Math.round(sw*k)), H=Math.max(8,Math.round(sh*k));
  const c=document.createElement("canvas"); c.width=W; c.height=H;
  const g=c.getContext("2d",{willReadFrequently:true}); g.imageSmoothingQuality="high"; g.drawImage(src,sx,sy,sw,sh,0,0,W,H);
  const rgba=g.getImageData(0,0,W,H).data;
  await pause();
  const inputs=await seg.proc(new lib.RawImage(new Uint8ClampedArray(rgba),W,H,4).rgb());
  await pause();
  const out=await seg.model(inputs);                       /* l'inferenza: l'unico passo lungo, non interrompibile */
  await pause();
  /* per ogni pixel la classe più probabile, già riportata alla dimensione della vista */
  const sgm=seg.proc.post_process_semantic_segmentation(out,[[H,W]])[0].segmentation, sd=sgm.data, N=W*H, lab=new Uint8Array(N);
  if(sd.length!==N) throw new Error("mappa delle classi di dimensione inattesa");
  for(let i=0;i<N;i++) lab[i]=seg.map[sd[i]&255];
  try{ for(const k in out){ const t=out[k]; if(t&&typeof t.dispose==="function") t.dispose(); } for(const k in inputs){ const t=inputs[k]; if(t&&typeof t.dispose==="function") t.dispose(); } }catch(_){}
  c.width=c.height=1;
  return {z,W,H,lab,rgba};
}
function view(src,z){
  let m=views.get(src); if(!m){ m=new Map(); views.set(src,m); }
  const key=z.map(v=>v.toFixed(3)).join(",");
  let p=m.get(key);
  if(!p){
    /* in coda: due inferenze insieme raddoppierebbero solo la memoria. Il limite di tempo vale dall'inizio dell'analisi, non dall'attesa. */
    const run=queue.then(()=>limit(parse(src,z),T_RUN));
    queue=run.then(()=>{},()=>{});
    p=run.catch(e=>{ m.delete(key); throw e; });
    p.catch(()=>{});
    m.set(key,p);
  }
  return p;
}

/* ---------- dalla mappa delle classi alla maschera di un capo ---------- */
/* classi da cercare: prima scelta, poi un'aggiunta se la prima non basta (il modello confonde gonna/abito/pantaloni e cappotto lungo/abito) */
function classesFor(h){
  const cat=String(h.cat||"").toLowerCase(), type=String(h.type||"").toLowerCase();
  if(UPPER_CATS.has(cat)) return {a:[UPPER],b:[DRESS,SCARF]};
  if(cat==="sotto") return {a:[SKIRT,PANTS],b:[DRESS]};
  if(cat==="intero") return {a:[DRESS,UPPER,SKIRT,PANTS],b:null};
  if(cat==="scarpe") return {a:[LSHOE,RSHOE],b:null};
  if(cat==="accessori"){ const c=ACC[type];
    if(c) return {a:[c],b:null};
    /* orologi, gioielli, cravatte, guanti...: il modello non li conosce. Solo senza un tipo si prova la classe più presente. */
    return type?{a:null,b:null}:{a:null,b:null,guess:[HAT,GLASSES,BAG,SCARF,BELT]}; }
  return {a:null,b:null};
}
/* componenti connesse (4 vicini) di m, larga w e alta h. Tiene le più grandi (fino a keep, ognuna almeno un quarto della maggiore),
   cancella il resto e restituisce {tot: pixel prima, kept: pixel dopo} */
function prune(m,w,h,keep){
  const N=w*h, id=new Int32Array(N), st=new Int32Array(N), sizes=[0]; let tot=0, n=0;
  for(let s=0;s<N;s++){
    if(!m[s]||id[s]) continue;
    n++; let top=0, cnt=0; st[top++]=s; id[s]=n;
    while(top){ const i=st[--top], x=i%w; cnt++;
      if(x>0&&m[i-1]&&!id[i-1]){ id[i-1]=n; st[top++]=i-1; }
      if(x<w-1&&m[i+1]&&!id[i+1]){ id[i+1]=n; st[top++]=i+1; }
      if(i>=w&&m[i-w]&&!id[i-w]){ id[i-w]=n; st[top++]=i-w; }
      if(i+w<N&&m[i+w]&&!id[i+w]){ id[i+w]=n; st[top++]=i+w; } }
    sizes.push(cnt); tot+=cnt;
  }
  if(!n) return {tot:0,kept:0};
  const order=sizes.map((c,i)=>i).slice(1).sort((a,b)=>sizes[b]-sizes[a]), big=sizes[order[0]], ok=new Uint8Array(n+1); let kept=0;
  for(let j=0;j<order.length&&j<keep;j++){ const c=sizes[order[j]]; if(c*4<big) break; ok[order[j]]=1; kept+=c; }
  for(let i=0;i<N;i++){ if(m[i]&&!ok[id[i]]) m[i]=0; }
  return {tot,kept};
}
function rgbOf(hex){ const s=String(hex||""); if(!/^#[0-9a-f]{6}$/i.test(s)) return null; const n=parseInt(s.slice(1),16); return [n>>16,(n>>8)&255,n&255]; }
/* giacca sopra la maglia: il modello le vede come un'unica classe. Se nella zona ci sono due colori ben distinti e compatti,
   tiene quello più vicino al colore del capo indicato da chi chiama. Restituisce true se ha diviso. */
function splitByColor(m,w,h,ox,oy,v,hex){
  const want=rgbOf(hex); if(!want) return false;
  const px=[]; for(let y=0;y<h;y++) for(let x=0;x<w;x++){ if(m[y*w+x]) px.push(y*w+x); }
  const n=px.length; if(n<400) return false;
  const col=i=>{ const o=((oy+((i/w)|0))*v.W+ox+i%w)*4; return o; }, d=v.rgba;
  const dist=(o,c)=>{ const a=d[o]-c[0], b=d[o+1]-c[1], e=d[o+2]-c[2]; return a*a+b*b+e*e; };
  const step=Math.max(1,(n/6000)|0);
  /* due centri: il colore indicato e il pixel che gli somiglia meno */
  let c1=want.slice(), c2=null, far=-1;
  for(let j=0;j<n;j+=step){ const o=col(px[j]), q=dist(o,c1); if(q>far){ far=q; c2=[d[o],d[o+1],d[o+2]]; } }
  if(!c2||far<70*70) return false;
  for(let it=0;it<8;it++){
    const s1=[0,0,0,0], s2=[0,0,0,0];
    for(let j=0;j<n;j+=step){ const o=col(px[j]), s=dist(o,c1)<=dist(o,c2)?s1:s2; s[0]+=d[o]; s[1]+=d[o+1]; s[2]+=d[o+2]; s[3]++; }
    if(!s1[3]||!s2[3]) return false;
    c1=[s1[0]/s1[3],s1[1]/s1[3],s1[2]/s1[3]]; c2=[s2[0]/s2[3],s2[1]/s2[3],s2[2]/s2[3]];
  }
  const dc=Math.sqrt((c1[0]-c2[0])**2+(c1[1]-c2[1])**2+(c1[2]-c2[2])**2); if(dc<70) return false;
  const dw=c=>Math.sqrt((want[0]-c[0])**2+(want[1]-c[1])**2+(want[2]-c[2])**2), d1=dw(c1), d2=dw(c2);
  if(Math.min(d1,d2)>Math.max(d1,d2)*.8) return false;                 /* il colore indicato non sceglie con chiarezza */
  const mine=d1<=d2?c1:c2, other=d1<=d2?c2:c1, part=new Uint8Array(w*h); let cnt=0;
  for(let j=0;j<n;j++){ const i=px[j], o=col(i); if(dist(o,mine)<=dist(o,other)){ part[i]=1; cnt++; } }
  if(cnt<n*.15||cnt>n*.85) return false;                               /* quasi tutto di un colore: è un capo solo */
  const r=prune(part,w,h,4); if(r.kept<r.tot*.8) return false;         /* macchie sparse: è una fantasia, non due capi */
  m.set(part); return true;
}
/* chiude i forellini (bottoni, pieghe) senza mai invadere pelle e capelli */
function close1(m,w,h,ox,oy,v){
  const add=[];
  for(let y=1;y<h-1;y++) for(let x=1;x<w-1;x++){ const i=y*w+x; if(m[i]) continue;
    if(m[i-1]+m[i+1]+m[i-w]+m[i+w]>=3&&!BODY.has(v.lab[(oy+y)*v.W+ox+x])) add.push(i); }
  for(const i of add) m[i]=1;
}
/* maschera del capo nella vista v, per il riquadro box (frazioni della foto intera). null se non convince. */
async function build(v,box,hint){
  const zw=v.z[2]-v.z[0], zh=v.z[3]-v.z[1];
  const fx0=clamp((box[0]-v.z[0])/zw,0,1)*v.W, fx1=clamp((box[2]-v.z[0])/zw,0,1)*v.W, fy0=clamp((box[1]-v.z[1])/zh,0,1)*v.H, fy1=clamp((box[3]-v.z[1])/zh,0,1)*v.H;
  const x0=Math.floor(fx0), y0=Math.floor(fy0), w=Math.min(v.W,Math.ceil(fx1))-x0, h=Math.min(v.H,Math.ceil(fy1))-y0;
  if(w<6||h<6) return null;
  const cat=String(hint.cat||"").toLowerCase(), small=cat==="scarpe"||cat==="accessori", cl=classesFor(hint), N=w*h;
  const fill=set=>{ const m=new Uint8Array(N); let c=0; for(let y=0;y<h;y++){ const r=(y0+y)*v.W+x0; for(let x=0;x<w;x++){ if(set.has(v.lab[r+x])){ m[y*w+x]=1; c++; } } } return {m,c}; };
  let a=cl.a;
  if(!a&&cl.guess){ /* accessorio di tipo ignoto: la classe più presente nel riquadro */
    let best=0; for(const c of cl.guess){ const f=fill(new Set([c])).c; if(f>best){ best=f; a=[c]; } } }
  if(!a) return null;
  const minFill=small?.05:.12;
  let r=fill(new Set(a));
  if(r.c<N*minFill&&cl.b) r=fill(new Set(a.concat(cl.b)));
  if(r.c<N*minFill) return null;
  const m=r.m; await pause();
  let split=false;
  if(UPPER_CATS.has(cat)) split=splitByColor(m,w,h,x0,y0,v,hint.hex);
  close1(m,w,h,x0,y0,v);
  const pr=prune(m,w,h,cat==="scarpe"?2:3);
  const f=pr.kept/N, share=pr.kept/Math.max(1,pr.tot);
  if(pr.kept<(small?60:150)||f<minFill||f>.97||share<.6) return null;
  /* fiducia: quanto è compatta la maschera, quanto riempie il riquadro in modo credibile, quanti pixel veri ha */
  const fit=f<.25?.5+.5*(f-minFill)/(.25-minFill):f>.9?.5+.5*(.97-f)/.07:1;
  const score=clamp(share*fit*Math.min(1,.6+.4*pr.kept/1500)*(split?.85:1),0,1);
  return {m,x0,y0,w,h,sx:fx0-x0,sy:fy0-y0,sw:Math.max(1,fx1-fx0),sh:Math.max(1,fy1-fy0),score,px:pr.kept};
}
/* porta la maschera alla risoluzione del riquadro: alfa 255 sul capo, 0 fuori, bordo morbido di pochi pixel */
async function render(src,box,b){
  const bw=Math.max(1,(box[2]-box[0])*src.width), bh=Math.max(1,(box[3]-box[1])*src.height), k=Math.min(1,OUT_MAX/Math.max(bw,bh));
  const W=Math.max(2,Math.round(bw*k)), H=Math.max(2,Math.round(bh*k));
  const s=document.createElement("canvas"); s.width=b.w; s.height=b.h; const sg=s.getContext("2d"), im=sg.createImageData(b.w,b.h), sd=im.data;
  for(let i=0,n=b.w*b.h;i<n;i++){ if(b.m[i]) sd[i*4+3]=255; }
  sg.putImageData(im,0,0);
  const c=document.createElement("canvas"); c.width=W; c.height=H; const g=c.getContext("2d",{willReadFrequently:true});
  g.imageSmoothingEnabled=true; g.imageSmoothingQuality="high";
  let up=W/b.sw;
  if(up<2){ /* maschera già quasi a grandezza piena: il bordo sarebbe a scalini. La si rimpicciolisce prima, così l'ingrandimento la ammorbidisce. */
    const q=up/2, t=document.createElement("canvas"); t.width=Math.max(1,Math.round(b.w*q)); t.height=Math.max(1,Math.round(b.h*q));
    const tg=t.getContext("2d"); tg.imageSmoothingEnabled=true; tg.imageSmoothingQuality="high"; tg.drawImage(s,0,0,t.width,t.height);
    const qx=t.width/b.w, qy=t.height/b.h; g.drawImage(t,b.sx*qx,b.sy*qy,b.sw*qx,b.sh*qy,0,0,W,H); t.width=t.height=1; up=2;
  } else g.drawImage(s,b.sx,b.sy,b.sw,b.sh,0,0,W,H);
  /* l'ingrandimento sfuma il bordo quanto il fattore di scala: lo si stringe attorno alla soglia per lasciare solo una piuma leggera */
  const gain=clamp(up/2.5,1,6), rows=Math.max(16,Math.floor(400000/W));
  for(let y=0;y<H;y+=rows){
    const hh=Math.min(rows,H-y), o=g.getImageData(0,y,W,hh), d=o.data;
    for(let i=3;i<d.length;i+=4){ const a=(d[i]-127.5)*gain+127.5; d[i]=a<0?0:a>255?255:a; d[i-1]=d[i-2]=d[i-3]=0; }
    g.putImageData(o,0,y); if(y+rows<H) await pause();
  }
  s.width=s.height=1;
  return c;
}

async function mask(src,box,hint,signal){
  try{
    if(off||!src||!src.width||!src.height||(signal&&signal.aborted)) return null;
    hint=hint||{};
    let bx=Array.isArray(box)?box.slice(0,4).map(Number):null;
    if(!bx||bx.length!==4||bx.some(v=>!isFinite(v))) return null;
    bx=[clamp(Math.min(bx[0],bx[2]),0,1),clamp(Math.min(bx[1],bx[3]),0,1),clamp(Math.max(bx[0],bx[2]),0,1),clamp(Math.max(bx[1],bx[3]),0,1)];
    if(bx[2]-bx[0]<.01||bx[3]-bx[1]<.01) return null;
    if(!classesFor(hint).a&&!classesFor(hint).guess) return null;      /* capo che il modello non conosce: inutile caricarlo */
    try{ await limit(load(),T_LOAD,signal); }
    catch(e){ if(!(e&&e.code==="cancelled")){ if(e&&e.code==="timeout") fail(e); else { off=true; fail(e); } } return null; }
    const get=async z=>{ try{ return await limit(view(src,z),T_RUN+T_RUN,signal); }catch(e){ if(!(e&&e.code==="cancelled")) fail(e); return null; } };
    const v=await get([0,0,1,1]); if(!v||(signal&&signal.aborted)) return null;
    let b=await build(v,bx,hint);
    /* scarpe e accessori piccoli: seconda analisi su una zona larga il doppio del riquadro, dove il capo occupa molti più pixel */
    const cat=String(hint.cat||"").toLowerCase(), area=(bx[2]-bx[0])*(bx[3]-bx[1]);
    if((cat==="scarpe"||cat==="accessori")&&area<.08&&(!b||b.px<2500)){
      const cx=(bx[0]+bx[2])/2, cy=(bx[1]+bx[3])/2, hw=bx[2]-bx[0], hh=bx[3]-bx[1];
      const z=[clamp(cx-hw,0,1),clamp(cy-hh,0,1),clamp(cx+hw,0,1),clamp(cy+hh,0,1)];
      const v2=await get(z); if(signal&&signal.aborted) return null;
      const b2=v2?await build(v2,bx,hint):null;
      if(b2&&(!b||b2.score>=b.score*.8)) b=b2;
    }
    if(!b||(signal&&signal.aborted)) return null;
    const cv=await render(src,bx,b);
    if(signal&&signal.aborted) return null;
    return {mask:cv,score:Math.round(b.score*100)/100};
  }catch(e){ fail(e); return null; }
}

window.GrucciaSeg={ready,mask};
})();
