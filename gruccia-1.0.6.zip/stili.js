/* ---------- stili: solo dati per il motore di abbinamento ----------
   Script classico (niente moduli). Definisce window.GRUCCIA_STILI = { COL, STILI, ORDINE }.

   COL: famiglie di colore in OKLCH. Ogni voce è [Lmin, Lmax, Cmin, Cmax, hmin, hmax]
     (L da 0 a 1, C da 0 a 0.4, tinta in gradi).
     - Se hmin > hmax la tinta "gira" attorno a 360 (es. bordeaux: 350 → 30).
     - Se Cmax <= 0.04 la tinta va ignorata (colori quasi acromatici).
     - "denim" si sovrappone ad "azzurro" e "navy": per riconoscerlo conviene usare
       type === "jeans" o la parola "denim" più che il colore.
     - I valori sono un punto di partenza, da ritoccare sulle foto vere.

   STILI: per ogni stile
     nome, descr        testi per l'interfaccia
     tipi               voto per tipo di capo: +1 firma, 0 va bene, -1 fuori stile. I tipi non elencati valgono 0.
     scarpe             voto per tipo di scarpa, colori (nomi di COL) e parole a favore / contro
     colori             core, accenti, no: nomi di COL
     maxColori          numero massimo di colori cromatici (fuori dai neutri) nel look
     contrasto          "basso" | "medio" | "alto" (contrasto di luminosità tra sopra e sotto)
     pattern            voto per tinta | righe | quadri | fantasia
     parole             pro / contro: radici da cercare (minuscolo, senza accenti) in style + notes + name
     formalita          [min, max] come indici di FORM_N (0 sportivo, 1 casual, 2 smart, 3 elegante)
     tonale             true se lo stile ammette look tono su tono (alle condizioni scritte nella specifica)
     tonaleSolo         se presente, l'unica famiglia in cui il tono su tono è ammesso (es. "nero")
     completo           se presente, giacca+pantaloni (o felpa+pantaloni) dello stesso colore valgono come
                        completo: dLmax = differenza massima di L tra i due pezzi; dLcamicia = stacco minimo del capo sotto
     gate               condizioni minime perché un look possa dirsi di questo stile (null = nessuna):
                          tutti: [tipi]                 devono esserci tutti
                          unoTra: [[tipi], [tipi]...]   per ogni gruppo deve esserci almeno un tipo
                          noSportivi: true              nessun capo con formalità "sportivo"
                          minSmart: n                   almeno n capi con formalità "smart" o superiore
                          formalitaMedia: [min, max]    media della formalità dei capi visibili
                          minSportivi: n                almeno n capi "sportivo"
                          scarpeSportive: true          tra i capi sportivi devono esserci le scarpe
                          minTecnici: n                 almeno n segnali tecnici (parola a favore, o tipo "piumino")
                          tecnicoIn: [categorie]        almeno uno dei segnali tecnici in una di queste categorie
                          maxScarto: n                  scarto massimo di formalità tra i capi
     maxAccessori       numero massimo di accessori
     maxNeri            numero massimo di capi principali neri (oltre scatta l'errore "troppo_nero")
     accentoCmax        croma massima ammessa per l'unico accento
     passoTonale        stacco minimo di L in un look tono su tono
     denimSuDenim       { dLmin }: stacco minimo di L tra due capi in denim
     ripiego            true = stile di ripiego: non risponde mai "non riesco"
     firma              combinazioni tipiche, come elenchi di tipi
     sblocca            tre acquisti che sbloccano lo stile, in ordine di importanza
     errori             [{ id, punti, descr }]: gli sbagli tipici. punti è nella scala di analyze();
                        descr è l'avviso da mostrare. Se c'è tettoFit, l'errore non toglie punti
                        ma limita il punteggio di stile a quel valore.

   ORDINE: gli id nell'ordine in cui mostrare i chip.
*/
window.GRUCCIA_STILI = {
  COL: {
    nero:[0,.27,0,.03,0,360], antracite:[.27,.45,0,.03,0,360], grigio:[.45,.90,0,.02,0,360],
    bianco:[.94,1,0,.02,0,360], crema:[.88,.97,.01,.05,60,110], beige:[.68,.90,.02,.065,60,105],
    cammello:[.60,.78,.06,.11,55,90], marrone:[.25,.60,.03,.11,40,80],
    navy:[.15,.40,.03,.10,245,285], azzurro:[.72,.90,.03,.09,235,265], denim:[.40,.75,.04,.11,245,270],
    oliva:[.35,.60,.04,.11,100,140], salvia:[.62,.82,.03,.08,110,165], bottiglia:[.22,.45,.04,.12,150,185],
    bordeaux:[.22,.44,.07,.17,350,30], ruggine:[.45,.64,.10,.18,30,55], senape:[.62,.80,.10,.17,75,100],
    arancio:[.60,.78,.15,.24,40,70], rosso:[.45,.65,.17,.27,15,35],
    pastello:[.78,.93,.03,.09,0,360], vivace:[.45,.90,.17,.40,0,360], neon:[.65,1,.22,.40,0,360]
  },

  ORDINE: ["casual","smart","oldmoney","sartoriale","minimal","street","sport","outdoor","workwear"],

  STILI: {
    oldmoney: { nome:"Old money", descr:"Capi classici, colori naturali e nessun logo: eleganza che non alza la voce.",
      tipi:{camicia:1,polo:1,maglione:1,giacca:1,cappotto:1,pantaloni:1,gonna:1,abito:1,scarpe:1,stivali:1,cintura:1,orologio:1,sciarpa:1,felpa:-1,tuta:-1,piumino:-1,zaino:-1,berretto:-1},
      scarpe:{scarpe:1,stivali:1,sneakers:0,sandali:0,colori:["marrone","cammello","bordeaux","bianco","crema","navy"],pro:["mocassin","penny","nappin","scamosciat","pelle","cuoio","chelsea","polacchin","barca","oxford","derby","ballerin"],contro:["running","tecnic","mesh","suola alta","chunky","carrarmato","plateau","zeppa","borchie","logo","colorat","fluo","gomma"]},
      colori:{core:["bianco","crema","beige","cammello","marrone","navy","grigio","antracite","azzurro","denim"],accenti:["bordeaux","bottiglia","oliva","salvia","pastello"],no:["neon","vivace","arancio"]},
      abbinamenti:[
        {a:"navy", b:"crema", punti:1.5, descr:"Blu e crema: il classico"},
        {a:"navy", b:"bianco", punti:1.5, descr:"Blu e bianco, puliti"},
        {a:"navy", b:"azzurro", punti:1.2, descr:"Blu con camicia azzurra"},
        {a:"navy", b:"beige", punti:1.2, descr:"Blu e beige"},
        {a:"navy", b:"grigio", punti:1, descr:"Blu con pantaloni grigi"},
        {a:"navy", b:"cammello", punti:1.2, descr:"Cammello sul blu"},
        {a:"navy", b:"bordeaux", punti:1, descr:"Blu con un tocco bordeaux"},
        {a:"cammello", b:"bianco", punti:1.2, descr:"Cammello e bianco"},
        {a:"cammello", b:"crema", punti:1, descr:"Cammello e crema"},
        {a:"cammello", b:"grigio", punti:1, descr:"Cammello e grigio"},
        {a:"crema", b:"marrone", punti:1.2, descr:"Crema con marrone caldo"},
        {a:"beige", b:"bianco", punti:1, descr:"Beige e bianco, luminosi"},
        {a:"azzurro", b:"beige", punti:1.2, descr:"Azzurro e beige"},
        {a:"grigio", b:"bordeaux", punti:1.2, descr:"Grigio e bordeaux"},
        {a:"antracite", b:"bordeaux", punti:1.2, descr:"Antracite e bordeaux"},
        {a:"antracite", b:"crema", punti:1, descr:"Antracite e crema"},
        {a:"grigio", b:"bianco", punti:.8, descr:"Grigio e bianco"},
        {a:"oliva", b:"crema", punti:1, descr:"Verde oliva e crema"},
        {a:"bottiglia", b:"crema", punti:1, descr:"Verde bottiglia e crema"},
        {a:"bottiglia", b:"beige", punti:.8, descr:"Verde bottiglia e beige"}
      ],
      maxColori:1, contrasto:"basso", pattern:{tinta:1,righe:1,quadri:0,fantasia:-1},
      parole:{pro:["cashmere","lana","merino","lino","seta","scamosciat","pelle","pinces","vita alta","trecce","oxford","button-down","classic","sartorial","doppiopetto","tweed","velluto a coste","rugby","flanella","lambswool","alpaca","popeline","pique","chino","spigat","girocollo","dolcevita","bermuda","midi","trench"],contro:["logo","monogram","stampa","grafica","oversize","strappat","sdrucit","scolorit","skinny","aderent","cropped","tecnic","nylon","sintetic","poliestere","acrilic","ecopelle","lucid","paillettes","cargo","borchie","sportiv","fluo"]},
      formalita:[1,3], tonale:true,
      gate:{unoTra:[["camicia","maglione","polo","giacca"],["scarpe","stivali","sneakers","sandali"]], noSportivi:true},
      maxAccessori:2, maxNeri:1,
      firma:[
        ["maglione","camicia","pantaloni","scarpe"],
        ["camicia","pantaloni","scarpe"],
        ["polo","pantaloni","scarpe"],
        ["maglione","pantaloni","scarpe"],
        ["maglione","jeans","scarpe"],
        ["giacca","camicia","pantaloni","scarpe"],
        ["giacca","polo","pantaloni","scarpe"],
        ["giacca","maglione","pantaloni","scarpe"],
        ["giacca","maglione","pantaloni","stivali"],
        ["cappotto","maglione","pantaloni","stivali"],
        ["cappotto","maglione","jeans","stivali"],
        ["polo","shorts","scarpe"],
        ["camicia","shorts","sandali"],
        ["tshirt","pantaloni","sandali"],
        ["camicia","gonna","scarpe"],
        ["maglione","gonna","stivali"],
        ["abito","scarpe"],
        ["cappotto","abito","stivali"]
      ],
      sblocca:["Mocassini penny in pelle marrone o bordeaux, anche scamosciati","Maglione girocollo in lana fine o cashmere: blu, crema o cammello","Pantaloni dal taglio dritto in lana o cotone, beige o grigi"],
      errori:[
        {id:"logo", punti:-3, descr:"Loghi o stampe in vista"},
        {id:"lucido_tecnico", punti:-2, descr:"Tessuto lucido, sintetico o tecnico"},
        {id:"colore_saturo", punti:-2.5, descr:"Un colore troppo acceso"},
        {id:"sneakers_sportive", punti:-3, descr:"Sneakers sportive o da corsa"},
        {id:"beige_piatto", punti:-4, descr:"Tutto dello stesso beige, senza stacco"},
        {id:"troppo_nero", punti:-1.5, descr:"Troppo nero per questo stile"},
        {id:"denim_strappato", punti:-3, descr:"Jeans strappati o scoloriti"},
        {id:"troppo_aderente", punti:-2, descr:"Capi troppo aderenti"},
        {id:"cargo", punti:-2, descr:"Pantaloni cargo"},
        {id:"sandali_gomma", punti:-2, descr:"Sandali di gomma o sportivi"},
        {id:"scarpe_vistose", punti:-2, descr:"Scarpe con suola massiccia o dettagli vistosi"}
      ] },

    sartoriale: { nome:"Sartoriale", descr:"Giacca, camicia e scarpe di pelle: il classico italiano, morbido e curato.",
      tipi:{giacca:1,camicia:1,pantaloni:1,scarpe:1,cravatta:1,cappotto:1,cintura:1,orologio:1,maglione:1,gonna:1,tshirt:-1,felpa:-1,giubbotto:-1,piumino:-1,jeans:-1,shorts:-1,tuta:-1,sneakers:-1,sandali:-1,zaino:-1,berretto:-1,top:-1},
      scarpe:{scarpe:1,stivali:0,sneakers:-1,sandali:-1,colori:["marrone","nero","bordeaux"],pro:["stringat","oxford","derby","mocassin","monk","pelle","cuoio","décolleté"],contro:["tela","gomma","running","tecnic"]},
      colori:{core:["navy","grigio","antracite","marrone","beige","bianco","azzurro","crema"],accenti:["bordeaux","bottiglia","cammello"],no:["neon","vivace","arancio"]},
      maxColori:2, contrasto:"medio", pattern:{tinta:1,righe:1,quadri:1,fantasia:-1},
      parole:{pro:["sartorial","destrutturat","doppiopetto","lana","flanella","fresco lana","lino","pinces","gessat","principe di galles","spigat","popeline","oxford","pelle","su misura"],contro:["jersey","felpat","tecnic","strappat","logo","oversize","cargo","denim","cappuccio","elasticizzat"]},
      formalita:[2,3], tonale:true,
      completo:{pezzi:["giacca","pantaloni"], dLmax:.04, dLcamicia:.25},
      gate:{tutti:["giacca"], unoTra:[["camicia","maglione","polo"],["pantaloni","gonna","abito"],["scarpe","stivali"]]},
      maxAccessori:3,
      firma:[["giacca","camicia","pantaloni","scarpe"],["giacca","camicia","pantaloni","scarpe","cravatta"],["giacca","maglione","pantaloni","scarpe"],["cappotto","giacca","camicia","pantaloni","scarpe"],["giacca","camicia","gonna","scarpe"]],
      sblocca:["Giacca blu destrutturata","Scarpe stringate o mocassini marrone scuro","Pantaloni grigi in lana"],
      errori:[
        {id:"quasi_completo", punti:-3, descr:"Giacca e pantaloni quasi uguali, ma non un completo"},
        {id:"sneakers_o_jeans", punti:-3, descr:"Sneakers o jeans: è smart casual, non sartoriale"},
        {id:"cintura_scarpe", punti:-2, descr:"Cintura e scarpe di pelle diversa"},
        {id:"troppe_fantasie", punti:-2, descr:"Troppe fantasie tra giacca, camicia e cravatta"},
        {id:"nere_di_giorno", punti:-1.5, descr:"Scarpe nere con pantaloni chiari di giorno"}
      ] },

    smart: { nome:"Smart casual", descr:"Un capo curato e uno rilassato: in ordine senza sembrare in ufficio.",
      tipi:{camicia:1,polo:1,maglione:1,giacca:1,pantaloni:1,jeans:1,gonna:1,abito:1,sneakers:1,scarpe:1,stivali:1,giubbotto:1,cappotto:1,cintura:1,orologio:1,borsa:1,felpa:-1,tuta:-1,cravatta:-1},
      scarpe:{sneakers:1,scarpe:1,stivali:1,sandali:0,colori:["bianco","crema","marrone","cammello","nero","navy"],pro:["pelle","scamosciat","mocassin","chelsea","polacchin","minimal","bass"],contro:["running","tecnic","trail","chunky","fluo","ciabatt"]},
      colori:{core:["navy","grigio","antracite","bianco","crema","beige","denim","nero","marrone","oliva","azzurro"],accenti:["bordeaux","bottiglia","ruggine","salvia","senape"],no:["neon"]},
      maxColori:2, contrasto:"medio", pattern:{tinta:1,righe:1,quadri:0,fantasia:0},
      parole:{pro:["chino","oxford","lino","lana","merino","overshirt","slim","regolare","pulit","scuro","pelle","scamosciat","destrutturat"],contro:["strappat","grafica","logo","tecnic","felpat","cappuccio","baggy","sdrucit"]},
      formalita:[1,2], tonale:false,
      gate:{formalitaMedia:[1.3,2.3], minSmart:1, noSportivi:true},
      maxAccessori:3,
      firma:[["giacca","tshirt","jeans","sneakers"],["maglione","camicia","pantaloni","sneakers"],["camicia","pantaloni","scarpe"],["polo","pantaloni","sneakers"],["giubbotto","maglione","jeans","stivali"],["giacca","top","jeans","scarpe"],["camicia","gonna","stivali"]],
      sblocca:["Giacca blu destrutturata","Sneakers bianche in pelle, pulite e basse","Chino beige o blu"],
      errori:[
        {id:"tutto_uguale", punti:-2, descr:"Tutto elegante o tutto casual: manca il contrasto"},
        {id:"jeans_strappati", punti:-2.5, descr:"Jeans strappati"},
        {id:"running_con_giacca", punti:-3, descr:"Scarpe da corsa con la giacca"},
        {id:"grafica_sotto_giacca", punti:-2, descr:"T-shirt con stampa sotto la giacca"},
        {id:"felpa", punti:-2, descr:"La felpa abbassa troppo il tono"}
      ] },

    minimal: { nome:"Minimal", descr:"Pochi colori, linee pulite, nessuna decorazione: conta il taglio.",
      tipi:{tshirt:1,camicia:1,maglione:1,top:1,giacca:1,cappotto:1,pantaloni:1,jeans:1,gonna:1,abito:1,sneakers:1,scarpe:1,stivali:1,borsa:1,cravatta:-1,cappello:-1,zaino:-1},
      scarpe:{sneakers:1,scarpe:1,stivali:1,sandali:0,colori:["bianco","nero","grigio","crema","antracite"],pro:["tinta unita","pelle liscia","minimal","derby","chelsea","pulit"],contro:["colorat","logo","chunky","fantasia","tecnic","fluo"]},
      colori:{core:["nero","antracite","grigio","bianco","crema","beige","navy"],accenti:["salvia","azzurro","cammello"],no:["vivace","neon","arancio","rosso","senape","ruggine"]},
      maxColori:1, contrasto:"alto", pattern:{tinta:1,righe:-1,quadri:-1,fantasia:-1},
      parole:{pro:["minimal","pulit","essenzial","tinta unita","dritt","ampio","strutturat","lana","cotone pesante","pelle liscia","scandinav"],contro:["logo","stampa","grafica","strappat","borchie","ricam","lavaggio","sdrucit","vintage","paillettes","frange","western"]},
      formalita:[1,3], tonale:true,
      gate:null,
      maxAccessori:1, accentoCmax:.07, passoTonale:.15,
      firma:[["tshirt","pantaloni","sneakers"],["maglione","pantaloni","stivali"],["cappotto","maglione","pantaloni","sneakers"],["camicia","jeans","scarpe"],["cappotto","abito","stivali"],["top","gonna","sandali"]],
      sblocca:["Sneakers bianche o nere tinta unita","Cappotto dritto nero, grigio o cammello","Pantaloni neri dal taglio dritto o ampio"],
      errori:[
        {id:"logo_stampa", punti:-3, descr:"Loghi o stampe"},
        {id:"secondo_colore", punti:-3, descr:"Più di un colore"},
        {id:"neutri_caldi_freddi", punti:-1.5, descr:"Neutri caldi e freddi mescolati"},
        {id:"troppi_accessori", punti:-1, descr:"Troppi accessori"},
        {id:"denim_lavato", punti:-2, descr:"Jeans strappati o molto lavati"},
        {id:"righe", punti:-1, descr:"Le righe spezzano la pulizia"},
        {id:"quadri_fantasia", punti:-3, descr:"Quadri o fantasie"},
        {id:"scarpa_bicolore", punti:-2, descr:"Scarpe con un secondo colore"}
      ] },

    casual: { nome:"Casual", descr:"Il look di tutti i giorni: comodo, semplice, ben abbinato.",
      tipi:{tshirt:1,camicia:1,polo:1,maglione:1,felpa:1,giubbotto:1,piumino:1,jeans:1,pantaloni:1,shorts:1,abito:1,gonna:1,sneakers:1,zaino:1,berretto:1,occhiali:1,cravatta:-1,scarpe:-1},
      scarpe:{sneakers:1,stivali:0,sandali:0,scarpe:-1,colori:["bianco","crema","nero","grigio","navy","marrone"],pro:["tela","pelle","bass","retro","scamosciat","mocassin"],contro:["lucid","stringat","oxford","tacco alto"]},
      colori:{core:["denim","navy","bianco","grigio","nero","beige","oliva","crema","marrone","azzurro"],accenti:["bordeaux","bottiglia","ruggine","senape","salvia","pastello","rosso"],no:["neon"]},
      maxColori:2, contrasto:"medio", pattern:{tinta:1,righe:1,quadri:1,fantasia:0},
      parole:{pro:["cotone","denim","jersey","comod","regolare","dritt","basic","felpat"],contro:["sartorial","lucid","cerimonia","gessat","raso"]},
      formalita:[0,2], tonale:false,
      gate:{maxScarto:1},
      maxAccessori:2, ripiego:true,
      firma:[["tshirt","jeans","sneakers"],["felpa","tshirt","jeans","sneakers"],["giubbotto","maglione","jeans","sneakers"],["camicia","pantaloni","sneakers"],["polo","shorts","sneakers"],["abito","sneakers"]],
      sblocca:["Sneakers bianche","Jeans dritti blu medio","Giubbotto leggero tipo overshirt o bomber"],
      errori:[
        {id:"scarpe_eleganti", punti:-2.5, descr:"Scarpe eleganti con t-shirt e jeans"},
        {id:"cravatta", punti:-5, descr:"La cravatta non c’entra"},
        {id:"tutto_palestra", punti:-2, descr:"Tutto da palestra: è un look sportivo"},
        {id:"troppi_loghi", punti:-2, descr:"Troppi loghi grandi"}
      ] },

    street: { nome:"Streetwear", descr:"Volumi ampi, felpe, grafiche e sneakers protagoniste.",
      tipi:{tshirt:1,felpa:1,top:1,giubbotto:1,piumino:1,jeans:1,pantaloni:1,shorts:1,sneakers:1,berretto:1,cappello:1,zaino:1,borsa:1,giacca:-1,scarpe:-1,cravatta:-1,cintura:0,polo:0},
      scarpe:{sneakers:1,stivali:0,sandali:0,scarpe:-1,colori:["bianco","nero","grigio","crema","vivace","marrone"],pro:["retro","bass","skate","alta","scamosciat","suola in gomma","anfib","ciabatt","colorat"],contro:["mocassin","stringat","lucid","elegant"]},
      colori:{core:["nero","bianco","grigio","antracite","denim","oliva","beige","navy"],accenti:["vivace","rosso","arancio","senape","bottiglia","pastello"],no:[]},
      maxColori:2, contrasto:"alto", pattern:{tinta:1,righe:1,quadri:0,fantasia:1},
      parole:{pro:["oversize","ampio","baggy","cargo","logo","grafica","stampa","cappuccio","vintage","lavaggio","strappat","maglia da calcio","jersey","varsity","bomber","nylon","cropped","boxy","vita bassa","skate"],contro:["slim","skinny","aderent","sartorial","elegant","pinces","classic","gessat"]},
      formalita:[0,1], tonale:true, tonaleSolo:"nero",
      gate:{unoTra:[["felpa","tshirt","top"],["sneakers","stivali","sandali"]]},
      maxAccessori:2,
      firma:[["felpa","tshirt","jeans","sneakers"],["tshirt","pantaloni","sneakers"],["giubbotto","felpa","jeans","sneakers"],["piumino","felpa","pantaloni","sneakers"],["tshirt","shorts","sneakers"],["top","jeans","sneakers"]],
      sblocca:["Felpa con cappuccio oversize grigia o nera","Jeans ampi dal taglio largo","Sneakers basse dal gusto retro"],
      errori:[
        {id:"skinny_sotto_oversize", punti:-2.5, descr:"Jeans stretti sotto un sopra oversize"},
        {id:"tutto_slim", punti:-2, descr:"Nessun capo ampio: sopra e sotto stretti"},
        {id:"troppi_loghi", punti:-2, descr:"Troppi loghi o grafiche grandi"},
        {id:"scarpe_eleganti", punti:-4, descr:"Scarpe eleganti"},
        {id:"giacca_polo_chino", punti:-3, descr:"Giacca, polo e chino: troppo ordinato"},
        {id:"troppi_colori", punti:-3, descr:"Più di due colori accesi"},
        {id:"stivali_non_anfibi", punti:-2, descr:"Stivali non adatti: servono anfibi"}
      ] },

    sport: { nome:"Sportivo", descr:"Capi tecnici e comodi, puliti e coordinati: palestra e tempo libero.",
      tipi:{tuta:1,felpa:1,tshirt:1,top:1,shorts:1,pantaloni:1,sneakers:1,piumino:1,giubbotto:1,berretto:1,cappello:1,zaino:1,camicia:-1,giacca:-1,jeans:-1,scarpe:-1,stivali:-1,cravatta:-1,cintura:-1,abito:-1},
      scarpe:{sneakers:1,sandali:0,stivali:-1,scarpe:-1,colori:["bianco","nero","grigio","navy","vivace"],pro:["running","tecnic","mesh","training","ammortizzat","ciabatt"],contro:["pelle liscia","mocassin","stringat","tacco","scamosciat"]},
      colori:{core:["nero","antracite","grigio","bianco","navy"],accenti:["vivace","neon","rosso","arancio","pastello"],no:["marrone","cammello"]},
      maxColori:1, contrasto:"medio", pattern:{tinta:1,righe:0,quadri:-1,fantasia:0},
      parole:{pro:["tecnic","elasticizzat","jogger","leggings","felpat","traspirant","running","zip","coulisse","polsini","mesh","nylon","antivento","palestra"],contro:["lana","lino","denim","pelle","pinces","sartorial","rigid","velluto","seta"]},
      formalita:[0,1], tonale:true,
      completo:{pezzi:["felpa","pantaloni"], dLmax:.04},
      gate:{minSportivi:2, scarpeSportive:true},
      maxAccessori:2,
      firma:[["felpa","tshirt","pantaloni","sneakers"],["tshirt","shorts","sneakers"],["tuta","sneakers"],["giubbotto","tshirt","pantaloni","sneakers"],["piumino","felpa","pantaloni","sneakers"],["top","pantaloni","sneakers"]],
      sblocca:["Pantaloni jogger affusolati neri o grigi","Sneakers da running in colori sobri","Felpa con zip o giacca antivento"],
      errori:[
        {id:"jeans", punti:-3, descr:"I jeans non sono sportivi"},
        {id:"scarpe_pelle", punti:-4, descr:"Scarpe di pelle"},
        {id:"grigi_quasi_uguali", punti:-2, descr:"Due grigi quasi uguali, ma non coordinati"},
        {id:"troppi_accesi", punti:-2.5, descr:"Più di un colore acceso"},
        {id:"lana_lino", punti:-1.5, descr:"Lana o lino con capi tecnici"}
      ] },

    outdoor: { nome:"Outdoor", descr:"Capi tecnici da montagna portati in città, in toni di terra e pietra.",
      tipi:{giubbotto:1,piumino:1,felpa:1,pantaloni:1,shorts:1,stivali:1,sneakers:1,zaino:1,berretto:1,cappello:1,giacca:-1,cappotto:-1,scarpe:-1,cravatta:-1,abito:-1,gonna:-1},
      scarpe:{stivali:1,sneakers:1,sandali:0,scarpe:-1,colori:["marrone","oliva","grigio","nero","beige","arancio"],pro:["trail","trekking","scarponcin","tecnic","impermeabil","suola scolpita","running"],contro:["mocassin","stringat","lucid","pelle liscia","tacco"]},
      colori:{core:["oliva","salvia","beige","marrone","grigio","antracite","nero","navy"],accenti:["arancio","ruggine","senape","vivace"],no:["pastello"]},
      maxColori:2, contrasto:"medio", pattern:{tinta:1,righe:0,quadri:0,fantasia:0},
      parole:{pro:["tecnic","impermeabil","antivento","nylon","ripstop","pile","cargo","trekking","trail","cappuccio","zip","coulisse","trapuntat","softshell","gore-tex","guscio","montagna"],contro:["sartorial","elegant","seta","pinces","lucid","tacco","gessat","raso"]},
      formalita:[0,1], tonale:false,
      gate:{minTecnici:2, tecnicoIn:["capospalla","scarpe"]},
      maxAccessori:2,
      firma:[["giubbotto","felpa","pantaloni","stivali"],["giubbotto","tshirt","pantaloni","sneakers"],["piumino","felpa","pantaloni","stivali"],["felpa","tshirt","shorts","sneakers"],["piumino","maglione","jeans","stivali"]],
      sblocca:["Giacca a guscio impermeabile","Scarpe da trail o scarponcini","Pantaloni cargo o tecnici"],
      errori:[
        {id:"guscio_solo", punti:0, tettoFit:.5, descr:"Solo la giacca è tecnica: il resto è da ufficio"},
        {id:"scarpe_eleganti", punti:-4, descr:"Scarpe eleganti"},
        {id:"troppi_accesi", punti:-3, descr:"Più di un colore acceso"},
        {id:"giacca_cappotto", punti:-3, descr:"Giacca o cappotto sartoriale"},
        {id:"sneakers_bianche", punti:-1, descr:"Sneakers bianche lisce: poco da montagna"}
      ] },

    workwear: { nome:"Workwear", descr:"Denim, tela e stivali: capi robusti da lavoro, con gusto vintage.",
      tipi:{jeans:1,camicia:1,tshirt:1,giubbotto:1,maglione:1,pantaloni:1,stivali:1,berretto:1,cintura:1,cravatta:-1,tuta:-1,sandali:-1,top:-1},
      scarpe:{stivali:1,sneakers:0,scarpe:0,sandali:-1,colori:["marrone","cammello","beige","crema","nero"],pro:["cuoio","pelle","scamosciat","stivalett","tela","retro","lavoro","suola in gomma","polacchin"],contro:["running","tecnic","mesh","lucid","fluo"]},
      colori:{core:["denim","navy","beige","crema","oliva","marrone","cammello","grigio","bianco"],accenti:["ruggine","senape","bordeaux","rosso","bottiglia"],no:["neon","pastello"]},
      maxColori:2, contrasto:"medio", pattern:{tinta:1,righe:0,quadri:1,fantasia:-1},
      parole:{pro:["denim","tela","canvas","flanella","velluto a coste","chambray","cimosa","grezz","pesant","vintage","cuoio","pelle","scamosciat","tasche","lavoro","carpenter","western","robust"],contro:["tecnic","nylon","lucid","skinny","elasticizzat","logo","sartorial","seta","fluo"]},
      formalita:[1,2], tonale:false,
      denimSuDenim:{dLmin:.15},
      gate:{unoTra:[["jeans","pantaloni"],["camicia","tshirt"],["stivali","giubbotto"]]},
      maxAccessori:2,
      firma:[["giubbotto","tshirt","jeans","stivali"],["camicia","tshirt","jeans","stivali"],["giubbotto","camicia","pantaloni","stivali"],["maglione","camicia","jeans","stivali"],["camicia","jeans","sneakers"]],
      sblocca:["Stivaletti in pelle marrone","Giacca da lavoro in tela o giubbotto di jeans","Camicia di flanella a quadri o in denim"],
      errori:[
        {id:"denim_stesso_lavaggio", punti:-3, descr:"Denim sopra e sotto dello stesso lavaggio"},
        {id:"skinny", punti:-2, descr:"Jeans stretti o elasticizzati"},
        {id:"tecnico", punti:-2.5, descr:"Capi tecnici o in nylon"},
        {id:"costume", punti:-2, descr:"Cappello, stivali, doppio denim e quadri insieme: troppo"},
        {id:"scarpe_nere_lucide", punti:-2, descr:"Scarpe nere lucide"},
        {id:"scarpe_running", punti:-3, descr:"Scarpe da corsa tecniche"},
        {id:"nero", punti:-1, descr:"Il nero stona con denim e tela"}
      ] }
  }
};
