/* Gruccia — adattatore per l'app locale (Capacitor).
   Definisce window.claude.use(nome) come se lo aspetta index.html:
   - "db" e "user" restituiscono null: l'app salva da sola nell'archivio del dispositivo (IndexedDB);
   - "sample" chiama direttamente il servizio di AI scelto nel Profilo, con la chiave dell'utente.
   Servizi: Claude (a pagamento), Gemini e Groq (piano gratuito). Le chiavi restano solo su questo dispositivo
   e non finiscono mai nell'esportazione dell'armadio. */
(function(){
"use strict";

const CFG_STORE = "gruccia-ai", OLD_KEY_STORE = "gruccia-api-key";
const MAX_SIDE = 1568;
const TIMEOUT_MS = 180000;
const SYSTEM = "Sei l'assistente di un'app guardaroba. Rispondi sempre e solo con JSON valido, "
  + "senza testo prima o dopo e senza blocchi di codice.";

const cap = () => window.Capacitor || null;
const isNative = () => { const c=cap(); return !!(c && c.isNativePlatform && c.isNativePlatform()); };
const platform = () => { const c=cap(); try{ return (c && c.getPlatform && c.getPlatform()) || "web"; }catch(_){ return "web"; } };
const plugin = name => { const c=cap(); return (c && c.Plugins && c.Plugins[name]) || null; };
const fail = (code, message) => { const e=new Error(message||code); e.code=code; return e; };
const sleep = ms => new Promise(r=>setTimeout(r,ms));
const errText = d => String((d && d.error && (d.error.message || d.error.status || d.error.code || d.error.type)) || (d && d.message) || "").toLowerCase();

/* ---------- servizi di AI ----------
   Ogni servizio sa costruire la richiesta (build) e leggere la risposta (read), che restituisce il testo
   oppure lancia un errore con uno dei codici che l'app conosce.
   info: weak = modello meno preciso (prompt più corti); boxOrder = come il modello indica i riquadri;
         extraCalls = se conviene fare chiamate di rifinitura (no sui piani gratuiti, che hanno pochi usi al giorno). */
const PROVIDERS = {
  anthropic: {
    label:"Claude", free:false, keyHint:"sk-ant-…", keyUrl:"console.anthropic.com",
    detect:k=>/^sk-ant-/.test(k),
    /* per spendere meno sulla lettura delle foto: quick:"claude-haiku-5-5" */
    models:{ quick:"claude-opus-5-5", standard:"claude-opus-5-5" },
    info:{ weak:false, boxOrder:"xyxy", maxImages:4, extraCalls:true },
    prezzo:{ in:4, out:20 },   /* Claude Opus 5.5, dollari per milione di token */
    usage:d=>({ in:(d&&d.usage&&d.usage.input_tokens)||0, out:(d&&d.usage&&d.usage.output_tokens)||0 }),
    build({prompt, images, tier, key, model}){
      const content=images.map(data=>({ type:"image", source:{ type:"base64", media_type:"image/jpeg", data } }));
      content.push({ type:"text", text:prompt });
      const headers={ "Content-Type":"application/json", "x-api-key":key, "anthropic-version":"2026-10-21",
        "anthropic-beta":"server-side-fallback-2026-07-01" };
      /* nel browser (solo per provare l'app sul PC) l'API richiede un'intestazione esplicita */
      if(!isNative()) headers["anthropic-dangerous-direct-browser-access"]="true";
      return { url:"https://api.anthropic.com/v1/messages", headers,
        body:{ model, max_tokens:16000, system:SYSTEM, fallbacks:"default",
          output_config:{ effort: tier==="quick" ? "low" : "medium" }, messages:[{ role:"user", content }] } };
    },
    read(status, d){
      if(status<200 || status>=300){
        const m=errText(d);
        if(status===401 || status===403) throw fail("bad_key");
        if(status===429) throw fail("rate_limited");
        if(status===413) throw fail("prompt_too_large");
        if(status===400){
          if(m.indexOf("credit")>=0 || m.indexOf("billing")>=0) throw fail("no_credit");
          if(m.indexOf("image")>=0) throw fail("image_rejected");
          if(m.indexOf("too long")>=0 || m.indexOf("too large")>=0) throw fail("prompt_too_large");
        }
        throw fail("upstream_error");
      }
      if(!d || !Array.isArray(d.content)) throw fail("upstream_error");
      if(d.stop_reason==="refusal") throw fail("refused");
      return d.content.filter(b=>b && b.type==="text").map(b=>b.text).join("");
    }
  },

  gemini: {
    label:"Gemini", free:true, keyHint:"AIza… oppure AQ.…", keyUrl:"aistudio.google.com/apikey",
    detect:k=>/^(AIza|AQ\.)/.test(k),
    models:{ quick:"gemini-3.5-flash-lite", standard:"gemini-3.5-flash-lite" },
    info:{ weak:true, boxOrder:"yxyx1000", maxImages:4, extraCalls:false },
    limiteGiorno:500,          /* stima non ufficiale del piano gratuito */
    usage:d=>{ const u=(d&&d.usageMetadata)||{}; return { in:u.promptTokenCount||0, out:(u.candidatesTokenCount||0)+(u.thoughtsTokenCount||0) }; },
    build({prompt, images, key, model}){
      const parts=images.map(data=>({ inlineData:{ mimeType:"image/jpeg", data } }));
      parts.push({ text:prompt });
      return { url:"https://generativelanguage.googleapis.com/v1beta/models/"+encodeURIComponent(model)+":generateContent",
        headers:{ "Content-Type":"application/json", "x-goog-api-key":key },
        body:{ systemInstruction:{ parts:[{ text:SYSTEM }] }, contents:[{ role:"user", parts }],
          generationConfig:{ responseMimeType:"application/json", maxOutputTokens:8192 } } };
    },
    read(status, d){
      if(status<200 || status>=300){
        const m=errText(d);
        if(m.indexOf("verification")>=0) throw fail("verify_needed");
        if(status===401 || status===403 || m.indexOf("api key")>=0 || m.indexOf("api_key")>=0) throw fail("bad_key");
        if(status===429) throw fail("rate_limited");
        if(status===402) throw fail("no_credit");
        if(status===404) throw fail("bad_model");
        if(status===413) throw fail("prompt_too_large");
        if(status===400 && m.indexOf("image")>=0) throw fail("image_rejected");
        throw fail("upstream_error");
      }
      if(!d) throw fail("upstream_error");
      const c=Array.isArray(d.candidates) ? d.candidates[0] : null;
      const blocked=/SAFETY|PROHIBITED|BLOCK|SPII|RECITATION/i;
      if(!c){ if(d.promptFeedback && d.promptFeedback.blockReason) throw fail("refused"); throw fail("empty_completion"); }
      const text=((c.content && c.content.parts) || []).filter(p=>p && typeof p.text==="string" && !p.thought).map(p=>p.text).join("");
      if(!text.trim() && blocked.test(String(c.finishReason||""))) throw fail("refused");
      return text;
    }
  },

  /* qualunque servizio compatibile con il formato OpenAI; predefinito: Groq */
  openai: {
    label:"Groq", free:true, keyHint:"gsk_…", keyUrl:"console.groq.com/keys",
    detect:k=>/^gsk_/.test(k),
    baseUrl:"https://api.groq.com/openai/v1",
    models:{ quick:"qwen/qwen3.8-27b", standard:"qwen/qwen3.8-27b" },
    info:{ weak:true, boxOrder:"xyxy", maxImages:3, extraCalls:false },
    limiteGiorno:1000,         /* piano gratuito di Groq */
    usage:d=>({ in:(d&&d.usage&&d.usage.prompt_tokens)||0, out:(d&&d.usage&&d.usage.completion_tokens)||0 }),
    build({prompt, images, key, model, baseUrl}){
      const content=[{ type:"text", text:prompt }];
      for(const data of images) content.push({ type:"image_url", image_url:{ url:"data:image/jpeg;base64,"+data } });
      return { url:String(baseUrl||this.baseUrl).replace(/\/+$/,"")+"/chat/completions",
        headers:{ "Content-Type":"application/json", "Authorization":"Bearer "+key },
        body:{ model, max_completion_tokens:4000, messages:[{ role:"system", content:SYSTEM }, { role:"user", content }] } };
    },
    read(status, d){
      if(status<200 || status>=300){
        const m=errText(d);
        if(status===401 || status===403) throw fail("bad_key");
        if(status===429) throw fail("rate_limited");
        if(status===402) throw fail("no_credit");
        if(status===404) throw fail("bad_model");
        if(status===413 || m.indexOf("too large")>=0 || m.indexOf("context length")>=0) throw fail("prompt_too_large");
        if(status===400 && m.indexOf("image")>=0) throw fail("image_rejected");
        throw fail("upstream_error");
      }
      const c=d && Array.isArray(d.choices) ? d.choices[0] : null;
      if(!c || !c.message) throw fail("upstream_error");
      if(c.message.refusal) throw fail("refused");
      const t=c.message.content;
      return typeof t==="string" ? t : Array.isArray(t) ? t.map(p=>(p && p.text) || "").join("") : "";
    }
  }
};
const ORDER = ["anthropic","gemini","openai"];

/* ---------- impostazioni: servizio scelto, chiavi, modello facoltativo ---------- */
function loadCfg(){
  let c=null; try{ c=JSON.parse(localStorage.getItem(CFG_STORE)||"null"); }catch(_){}
  if(!c || typeof c!=="object") c={};
  if(!c.keys || typeof c.keys!=="object") c.keys={};
  if(!c.models || typeof c.models!=="object") c.models={};
  /* la prima versione dell'app salvava solo la chiave di Claude */
  try{ const old=(localStorage.getItem(OLD_KEY_STORE)||"").trim(); if(old && !c.keys.anthropic){ c.keys.anthropic=old; } if(old) localStorage.removeItem(OLD_KEY_STORE); }catch(_){}
  if(!PROVIDERS[c.provider]) c.provider = ORDER.find(id=>c.keys[id]) || "anthropic";
  return c;
}
function saveCfg(c){ try{ localStorage.setItem(CFG_STORE, JSON.stringify(c)); }catch(_){} }
let CFG = loadCfg(); saveCfg(CFG);

/* ---------- consumi: richieste e token di oggi e del mese, per servizio (solo su questo dispositivo) ---------- */
const USE_STORE = "gruccia-uso";
const z2 = n => String(n).padStart(2,"0");
const giorno = () => { const d=new Date(); return d.getFullYear()+"-"+z2(d.getMonth()+1)+"-"+z2(d.getDate()); };
function loadUse(){
  let u=null; try{ u=JSON.parse(localStorage.getItem(USE_STORE)||"null"); }catch(_){}
  if(!u || typeof u!=="object") u={};
  const g=giorno(), m=g.slice(0,7);
  if(u.giorno!==g){ u.giorno=g; u.d={}; }
  if(u.mese!==m){ u.mese=m; u.m={}; }
  if(!u.d || typeof u.d!=="object") u.d={}; if(!u.m || typeof u.m!=="object") u.m={};
  return u;
}
function track(id, t){
  const u=loadUse();
  for(const k of ["d","m"]){ const e=u[k][id]||(u[k][id]={calls:0,in:0,out:0}); e.calls++; e.in+=(t&&t.in)||0; e.out+=(t&&t.out)||0; }
  try{ localStorage.setItem(USE_STORE, JSON.stringify(u)); }catch(_){}
}

const AI = {
  /* consumi del servizio: oggi e nel mese; limite giornaliero (piani gratuiti) o costo stimato in dollari (Claude) */
  usage(id){ id=id||CFG.provider; const p=PROVIDERS[id], u=loadUse(), zero={calls:0,in:0,out:0};
    const oggi=Object.assign({},zero,u.d[id]), mese=Object.assign({},zero,u.m[id]);
    const costo=t=>p.prezzo ? (t.in*p.prezzo.in+t.out*p.prezzo.out)/1e6 : null;
    return { oggi, mese, limiteGiorno:p.limiteGiorno||null, costoOggi:costo(oggi), costoMese:costo(mese) }; },
  list(){ return ORDER.map(id=>{ const p=PROVIDERS[id]; return { id, label:p.label, free:p.free, keyHint:p.keyHint, keyUrl:p.keyUrl, model:p.models.standard, hasKey:!!CFG.keys[id] }; }); },
  provider(){ return CFG.provider; },
  setProvider(id){ if(PROVIDERS[id]){ CFG.provider=id; saveCfg(CFG); } return CFG.provider; },
  key(id){ return String(CFG.keys[id||CFG.provider]||""); },
  setKey(id, v){ v=String(v||"").trim(); if(!PROVIDERS[id]) return ""; if(v) CFG.keys[id]=v; else delete CFG.keys[id]; saveCfg(CFG); return v; },
  has(id){ return !!this.key(id); },
  masked(id){ const k=this.key(id); return k ? k.slice(0,8)+"…"+k.slice(-4) : ""; },
  /* riconosce il servizio dalla forma della chiave, così chi incolla la chiave sbagliata viene avvisato */
  detect(v){ v=String(v||"").trim(); return ORDER.find(id=>PROVIDERS[id].detect(v)) || null; },
  plausible(v){ v=String(v||"").trim(); return v.length>=20 && v.length<=400 && !/\s/.test(v); },
  model(id){ id=id||CFG.provider; return String(CFG.models[id]||""); },
  setModel(id, v){ v=String(v||"").trim(); if(!PROVIDERS[id]) return; if(v) CFG.models[id]=v; else delete CFG.models[id]; saveCfg(CFG); },
  info(){ const p=PROVIDERS[CFG.provider]; return Object.assign({ provider:CFG.provider }, p.info); }
};

/* ---------- immagini: lato lungo a 1568 px, JPEG in base64 ---------- */
function loadImage(blob){
  if(window.createImageBitmap) return createImageBitmap(blob, {imageOrientation:"from-image"}).catch(()=>loadImageTag(blob));
  return loadImageTag(blob);
}
function loadImageTag(blob){
  return new Promise((res,rej)=>{ const u=URL.createObjectURL(blob), im=new Image();
    im.onload=()=>{ URL.revokeObjectURL(u); res(im); }; im.onerror=()=>{ URL.revokeObjectURL(u); rej(fail("image_rejected")); }; im.src=u; });
}
async function toJpegBase64(blob){
  let src; try{ src=await loadImage(blob); }catch(_){ throw fail("image_rejected"); }
  const w=src.width, h=src.height; if(!w||!h) throw fail("image_rejected");
  const k=Math.min(1, MAX_SIDE/Math.max(w,h));
  const c=document.createElement("canvas"); c.width=Math.max(1,Math.round(w*k)); c.height=Math.max(1,Math.round(h*k));
  const g=c.getContext("2d"); g.fillStyle="#fff"; g.fillRect(0,0,c.width,c.height); g.drawImage(src,0,0,c.width,c.height);
  if(src.close) try{ src.close(); }catch(_){}
  const url=c.toDataURL("image/jpeg",.85), i=url.indexOf(",");
  c.width=c.height=0;
  if(i<0) throw fail("image_rejected");
  return url.slice(i+1);
}

/* ---------- chiamata HTTP: plugin nativo nell'app, fetch nel browser ---------- */
async function post(req){
  const http = isNative() ? plugin("CapacitorHttp") : null;
  if(http){
    const o={ url:req.url, method:"POST", headers:req.headers, data:req.body, readTimeout:TIMEOUT_MS };
    /* su iPhone il plugin usa connectTimeout come tempo massimo dell'intera richiesta: lì non va indicato */
    if(platform()!=="ios") o.connectTimeout=30000;
    let r;
    try{ r=await http.request(o); }catch(_){ throw fail("upstream_error"); }
    let data=r.data;
    if(typeof data==="string"){ try{ data=JSON.parse(data); }catch(_){ data=null; } }
    return { status:r.status, data };
  }
  let r;
  try{ r=await fetch(req.url, { method:"POST", headers:req.headers, body:JSON.stringify(req.body) }); }
  catch(_){ throw fail("upstream_error"); }
  let data=null; try{ data=await r.json(); }catch(_){}
  return { status:r.status, data };
}

/* ---------- JSON: il modello deve rispondere con solo JSON, ma i modelli più deboli sbagliano spesso la forma ---------- */
function tryParse(t){ try{ return { ok:true, v:JSON.parse(t) }; }catch(_){ return { ok:false }; } }
function parseJson(text){
  let t=String(text||"").trim();
  if(!t) throw fail("empty_completion");
  const m=t.match(/```(?:json)?\s*([\s\S]*?)\s*```/i); if(m && m[1].trim()) t=m[1].trim();
  let r=tryParse(t); if(r.ok) return r.v;
  /* testo attorno al JSON */
  const a=t.search(/[\[{]/); if(a<0) throw fail("invalid_json");
  const b=Math.max(t.lastIndexOf("]"), t.lastIndexOf("}"));
  let body = b>a ? t.slice(a,b+1) : t.slice(a);
  r=tryParse(body); if(r.ok) return r.v;
  /* virgole finali e commenti */
  const clean=body.replace(/^\s*\/\/.*$/gm,"").replace(/,\s*([\]}])/g,"$1");
  r=tryParse(clean); if(r.ok) return r.v;
  /* risposta troncata a metà di un elenco: tengo gli oggetti completi */
  if(clean[0]==="["){
    for(let i=clean.lastIndexOf("}"); i>0; i=clean.lastIndexOf("}", i-1)){
      r=tryParse(clean.slice(0,i+1).replace(/,\s*$/,"")+"]"); if(r.ok && Array.isArray(r.v) && r.v.length) return r.v;
    }
  }
  throw fail("invalid_json");
}

async function askJson(prompt, opts){
  opts = opts || {};
  const id = CFG.provider, p = PROVIDERS[id], key = AI.key(id);
  if(!key) throw fail("not_granted");
  const signal = opts.signal;
  if(signal && signal.aborted) throw fail("cancelled");
  const files = Array.from(opts.images || []);
  if(files.length > p.info.maxImages) throw fail("prompt_too_large");
  const tier = opts.modelTier==="quick" ? "quick" : "standard";

  const work = (async ()=>{
    const images=[]; for(const f of files) images.push(await toJpegBase64(f));
    const req = p.build({ prompt:String(prompt), images, tier, key, model:AI.model(id) || p.models[tier] });
    let r = await post(req);
    /* servizio momentaneamente sovraccarico: un solo nuovo tentativo */
    if((r.status===503 || r.status===529 || r.status===500) && !(signal && signal.aborted)){ await sleep(2500); r = await post(req); }
    /* conto la richiesta appena il servizio risponde con successo, anche se poi il JSON non fosse utilizzabile */
    if(r.status>=200 && r.status<300){ try{ track(id, p.usage ? p.usage(r.data) : null); }catch(_){} }
    return parseJson(p.read(r.status, r.data));
  })();

  if(!signal) return work;
  /* il plugin nativo non sa interrompere una richiesta: se l'utente annulla, smetto solo di aspettarla */
  return new Promise((res,rej)=>{
    const onAbort=()=>rej(fail("cancelled"));
    signal.addEventListener("abort", onAbort, {once:true});
    work.then(v=>{ signal.removeEventListener("abort",onAbort); res(v); }, e=>{ signal.removeEventListener("abort",onAbort); rej(e); });
  });
}

function makeSample(){
  const sample = (prompt, opts) => askJson(prompt, opts);
  sample.json = askJson;
  sample.limits = async () => ({ images:{ maxCount:PROVIDERS[CFG.provider].info.maxImages } });
  sample.info = () => AI.info();
  return sample;
}

window.claude = {
  use(name){
    if(name==="sample") return Promise.resolve(AI.has() ? makeSample() : null);
    return Promise.resolve(null); /* "db" e "user": nessun account, archivio locale */
  }
};
window.GrucciaAI = AI;

/* ---------- file: esporta e scegli dove salvare ---------- */
async function saveTextFile(name, text){
  const fs = isNative() ? plugin("Filesystem") : null, share = isNative() ? plugin("Share") : null;
  if(fs && share){
    /* scrivo a pezzi: un armadio con molte foto pesa decine di MB e in un colpo solo bloccherebbe il ponte nativo */
    const STEP = 512*1024;
    let pos=0, first=true;
    while(pos<text.length || first){
      let end=Math.min(text.length, pos+STEP);
      const last=text.charCodeAt(end-1);
      if(end<text.length && last>=0xD800 && last<=0xDBFF) end--; /* non spezzare una coppia surrogata */
      const data=text.slice(pos,end);
      if(first) await fs.writeFile({ path:name, data, directory:"CACHE", encoding:"utf8" });
      else await fs.appendFile({ path:name, data, directory:"CACHE", encoding:"utf8" });
      first=false; pos=end;
    }
    const uri=(await fs.getUri({ path:name, directory:"CACHE" })).uri;
    try{ await share.share({ title:name, files:[uri], dialogTitle:"Salva l’armadio" }); }
    catch(e){ const m=String((e&&e.message)||"").toLowerCase(); if(m.indexOf("cancel")<0) throw e; return "cancelled"; }
    return "shared";
  }
  const u=URL.createObjectURL(new Blob([text],{type:"application/json"})), a=document.createElement("a");
  a.href=u; a.download=name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(u),30000);
  return "downloaded";
}
window.GrucciaFile = { saveText:saveTextFile, native:isNative };
})();
